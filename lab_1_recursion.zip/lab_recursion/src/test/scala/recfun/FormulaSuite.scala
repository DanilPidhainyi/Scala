package recfun

import org.scalatest.funsuite.AnyFunSuite
import org.junit.runner.RunWith
import org.scalatestplus.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class FormulaSuite extends AnyFunSuite{
    import Main.formula

    test("formula: a = 1 x = 5") {
      assert(formula(1, 5) == 1)
    }

    test("formula: a = 1 x = 2") {  // ax ^ 1..13
      assert(formula(3, 2) == 3 * (2 + 4 + 8 + 16 + 32 + 64 + 128 + 256 + 512 + 1024 + 2048 + 2048 * 2 + 2048 * 4))
    }

    test("formula: a = 5 x = 1") {
      assert(formula(5, 1) == 5 * 13)
    }

    test("formula: a = 0 x = -5") {
      assert(formula(0, -5) == 0)
    }

}
