

package recfun

import scala.annotation.tailrec

object Main {
  def main(args: Array[String]) {
    println("Pascal's Triangle")
    for (row <- 0 to 10) {
      for (col <- 0 to row)
        print(pascal(col, row) + " ")
      println()
    }
  }

  /**
   * Exercise 1
   */
    def pascal(c: Int, r: Int): Int = {
      if (c == 0 || r == 1 || c == r) 1 else pascal(c - 1, r - 1) + pascal(c, r - 1)
    }

  /**
   * Exercise 2
   */
    def balance(chars: List[Char]): Boolean = {
      @tailrec
      def forChar(chars2: List[Char], counter: Int): Boolean = {
        if (chars2.isEmpty) counter == 0
        else if (chars2.head == '(') forChar(chars2.tail, counter + 1)
        else if (chars2.head == ')')
          if (counter == 0) false else forChar(chars2.tail, counter - 1)
        else forChar(chars2.tail, counter)
      }

      forChar(chars, 0)
    }
  
  /**
   * Exercise 3
   */
    def countChange(money: Int, coins: List[Int]): Int = {
      def brute_force(money: Int, coins: List[Int], counter: Int): Int = {
        if (coins.isEmpty) counter
        else if (money - coins.head == 0) brute_force(money, coins.tail, counter + 1)
        else if (money - coins.head > 0) brute_force(money - coins.head, coins, counter) + brute_force(money, coins.tail, 0)
        else brute_force(money, coins.tail, counter)
      }

      if (money == 0 || coins.isEmpty) 0
      else brute_force(money, coins, 0)
    }

  /**
   * Formula
   */
  def formula (a:Int, x:Int):Int = {

    @tailrec
    def pow_x(num:Int, i:Int):Int =
      if (i == 1) num else pow_x(num * x, i - 1)

    @tailrec
    def sum(accu: Int, k: Int):Int = {
      if (k == 1) accu + x else sum(accu + pow_x(x, k), k - 1)
    }

    require(a != x, "a = x is undefined")
    if (a < x) a else a * sum(0, 13)
  }
}

